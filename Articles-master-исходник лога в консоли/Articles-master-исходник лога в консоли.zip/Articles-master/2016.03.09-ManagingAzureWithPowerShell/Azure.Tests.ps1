$here = $PSScriptRoot
$sut = $PSCommandPath.Replace('.Tests', '')
. $sut