﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp7
{
    class NumericLiteralsImproved
    {
        const long LargeNumber = 1_0_0000_000_0;
        const int binaryNumber = 0b101_010;
    }
    
}
